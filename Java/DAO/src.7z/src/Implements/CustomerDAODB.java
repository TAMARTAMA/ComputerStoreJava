package Implements;

import Entities.Customer;
import Entities.GlobalDB;
import Interfaces.CustomerDAO;

import java.time.LocalDate;
import java.util.*;


class CustomerDAODB implements CustomerDAO {
    private Map<Long, Customer> mapCus = GlobalDB.getInstance()._Customers;

    public boolean isCustomerExistById(long id) {
        return mapCus.containsKey(id);
    }

    public boolean isCustomerExistByIdentity(Customer.Identity id) {
        return mapCus.values().stream()
                .anyMatch(customer -> customer.getIdentity().equals(id));

    }

    public void addCustomer(Customer c) {
        mapCus.put(c.getId(), c);
    }

    public void updateCustomer(Customer c) throws Exception {
        if (!mapCus.containsKey(c.getId())) {
            throw new Exception("Customer with ID " + c.getId() + " does not exist.");
        }
        mapCus.put(c.getId(), c);
    }

    public void removeCustomer(int id) throws Exception {
        if (!mapCus.containsKey(id)) {
            throw new Exception("Customer with ID " + id + " does not exist.");
        }
        mapCus.remove(id);
    }

    public Customer getCustomerById(int id) throws Exception {
        if (!mapCus.containsKey(id)) {
            throw new Exception("Customer with ID " + id + " does not exist.");
        }
        return mapCus.get(id);
    }

    public Customer getCustomerByIdentity(Customer.Identity identity) throws Exception {
        Optional<Customer> customer = mapCus.values().stream()
                .filter(c -> c.getIdentity().equals(identity))  // מסננים לקוחות שמתאימים
                .findFirst();
        if (customer.isEmpty()) {
            throw new Exception("Customer with identity " + identity + " not found.");
        }
        return customer.get();

    }

    public HashMap<Long, Customer> getAllCustomers() throws Exception {
        return (HashMap<Long, Customer>) mapCus;
    }

    //TODO if isnt good change!
    public ArrayList<Customer> getCustomersByDate(LocalDate ld) throws Exception {

        return (ArrayList<Customer>) mapCus.values().stream().filter(c -> c.getLocalDate().equals(ld));
    }
}

