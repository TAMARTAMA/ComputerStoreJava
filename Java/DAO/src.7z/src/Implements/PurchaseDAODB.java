package Implements;

import Entities.GlobalDB;
import Entities.Product;
import Entities.PurchaseOrder;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PurchaseDAODB {
    private List<PurchaseOrder> purchaseOrders = GlobalDB.getInstance()._PurchaseOrders;

    public boolean isPurchaseOrdersExistById(long id) {
        return purchaseOrders.stream().anyMatch(p-> p.getId()==id);
    }
    public PurchaseOrder getCustomerExistById(long id)throws Exception
    {
        PurchaseOrder p= (PurchaseOrder) purchaseOrders.stream().filter(pp -> (pp.getId() == id));
        if(p==null)
            throw new Exception("Product with ID " + id + " does not exist.");
        return p;
    }
    public void addPurchaseOrder(PurchaseOrder p) {
        purchaseOrders.add(p);
    }

    public void updatePurchaseOrder(PurchaseOrder p) throws Exception {
        try {
            removePurchaseOrder(p.getId());
        }
        catch (Exception e){
            throw  e;
        }
        addPurchaseOrder(p);
    }

    public void removePurchaseOrder(long id) throws Exception {
        purchaseOrders.remove(getCustomerExistById(id));
    }


    public List<PurchaseOrder> getAllPurchaseOrders() throws Exception {
        return purchaseOrders;
    }

}
