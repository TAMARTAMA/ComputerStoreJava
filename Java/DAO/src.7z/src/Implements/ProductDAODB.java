package Implements;

import Entities.Customer;
import Entities.GlobalDB;
import Entities.Product;
import Interfaces.ProductDAO;

import java.util.Set;

public class ProductDAODB implements ProductDAO {
    private Set<Product> products = GlobalDB.getInstance()._Products;

    public boolean isProductExistById(long id) {
        return products.stream().anyMatch(p -> (p.getId() == id));
    }

    public Product getProductById(long id) throws Exception {

        Product p= (Product) products.stream().filter(pp -> (pp.getId() == id));
        //TODO expitions
        if(p==null)
            throw new Exception("Product with ID " + id + " does not exist.");
        return  p;
    }

    public Set<Product> getAllProducts() throws Exception {
        return products;
    }
    public void addProduct(Product p) {
        products.add(p);
    }

    public void updateProduct(Product p) throws Exception {
        try {
            removeProduct(p.getId());
        }
        catch (Exception e){
            throw  e;
        }
        addProduct(p);
    }

    public void removeProduct(long id) throws Exception {
        products.remove(getProductById(id));
//        if (!mapCus.containsKey(id)) {
//            throw new Exception("Customer with ID " + id + " does not exist.");
//        }
//        mapCus.remove(id);
    }
}
