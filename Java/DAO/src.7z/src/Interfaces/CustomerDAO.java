
package Interfaces;

import Entities.Customer;
import Entities.GlobalDB;

import java.time.LocalDate;
import java.util.*;

public interface CustomerDAO {
     boolean isCustomerExistById(long id);
     boolean isCustomerExistByIdentity(Customer.Identity id);
     void addCustomer(Customer c);
     void updateCustomer(Customer c) throws Exception;
     void removeCustomer(int id)throws Exception;
     Customer getCustomerById(int id)throws Exception;
     Customer getCustomerByIdentity(Customer.Identity id) throws Exception;
    HashMap<Long, Customer> getAllCustomers()throws Exception;
    //TODO if isnt good change!
    ArrayList<Customer> getCustomersByDate(LocalDate ld)throws Exception;



}
